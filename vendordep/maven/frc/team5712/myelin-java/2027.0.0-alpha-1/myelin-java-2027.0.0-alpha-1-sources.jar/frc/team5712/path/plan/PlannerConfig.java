package frc.team5712.path.plan;

import frc.team5712.path.core.Footprint;
import frc.team5712.path.core.PathFile;
import java.util.Map;

/**
 * Pathfinder settings.
 *
 * @param bumperLengthMeters robot length with bumpers (along its heading)
 * @param bumperWidthMeters robot width with bumpers
 * @param marginMeters extra clearance on top of the bumpers' half-diagonal when obstacles are grown,
 *     and the clearance the swept-bumper check demands of the smoothed path
 * @param arcStepRadians largest step of the polygonal arcs that round the grown corners
 * @param maxRefits how many times the smoother may add waypoints and refit before giving up
 * @param checkStepMeters spacing of the swept-bumper check along the path
 * @param maxMetersPerSecond path speed cap
 * @param maxMetersPerSecondSquared path acceleration and braking cap
 * @param footprint the outline planned with: the bumpers, or the bumpers with a mechanism out ({@link
 *     #withFootprint}), e.g. to pathfind with the intake deployed
 */
public record PlannerConfig(
    double bumperLengthMeters,
    double bumperWidthMeters,
    double marginMeters,
    double arcStepRadians,
    int maxRefits,
    double checkStepMeters,
    double maxMetersPerSecond,
    double maxMetersPerSecondSquared,
    Footprint footprint) {

  /**
   * The margin on-the-fly paths try first (m): odometry can drift more than {@link #DEFAULT}'s 5 cm, so where
   * the field has room the robot keeps 15 cm off things; where it doesn't (a gap under 1.5 m for the 0.85 m
   * robot) the 5 cm plan still gets through. See {@code OnTheFly#preferring}.
   */
  public static final double WIDE_MARGIN_METERS = 0.15;

  /** 0.85 m square bumpers, 5 cm margin, 30° arcs, 8 refits, 2 cm checks, 4 m/s and 6 m/s². */
  public static final PlannerConfig DEFAULT =
      new PlannerConfig(0.85, 0.85, 0.05, Math.toRadians(30), 8, 0.02, 4.0, 6.0);

  public PlannerConfig {
    if (!(bumperLengthMeters > 0) || !(bumperWidthMeters > 0) || !(marginMeters >= 0)
        || !(arcStepRadians > 0) || arcStepRadians > Math.PI / 2 || maxRefits < 0
        || !(checkStepMeters > 0) || !(maxMetersPerSecond > 0) || !(maxMetersPerSecondSquared > 0)) {
      throw new IllegalArgumentException("bad planner settings");
    }
    if (footprint == null) {
      throw new IllegalArgumentException("a footprint is needed (Footprint.bumpers for the bumpers alone)");
    }
  }

  /** Settings planning with the bumpers alone. */
  public PlannerConfig(double bumperLengthMeters, double bumperWidthMeters, double marginMeters,
      double arcStepRadians, int maxRefits, double checkStepMeters, double maxMetersPerSecond,
      double maxMetersPerSecondSquared) {
    this(bumperLengthMeters, bumperWidthMeters, marginMeters, arcStepRadians, maxRefits, checkStepMeters,
        maxMetersPerSecond, maxMetersPerSecondSquared, Footprint.bumpers(bumperLengthMeters, bumperWidthMeters));
  }

  /**
   * {@link #DEFAULT} with the bumper size from a robot file's tree ({@code deploy/paths/robot.json},
   * keys {@code bumperLengthMeters} and {@code bumperWidthMeters}, both optional). The editor writes
   * them next to the {@code RobotConfig} keys, which {@code RobotFile} reads.
   *
   * <p>Two more optional keys set how hard on-the-fly paths (drive to a pose, pathfind) drive:
   * {@code onTheFlyMaxMetersPerSecond} (4 unless set) and {@code onTheFlyMaxMetersPerSecondSquared} (6 unless
   * set), the one limit for speeding up and for slowing down. The robot's own traction limit still applies, so
   * a number above it changes nothing. On the bench, 9 m/s² was 6 % faster than 6 with the wheel odometry no
   * further off; from there to the traction limit gained 1 % more and the odometry drifted 20 % further
   * (bench/RESULTS.md).
   */
  public static PlannerConfig fromRobotFile(Map<String, Object> robot) {
    return new PlannerConfig(
        PathFile.number(robot, "bumperLengthMeters", DEFAULT.bumperLengthMeters),
        PathFile.number(robot, "bumperWidthMeters", DEFAULT.bumperWidthMeters),
        DEFAULT.marginMeters, DEFAULT.arcStepRadians, DEFAULT.maxRefits, DEFAULT.checkStepMeters,
        PathFile.number(robot, "onTheFlyMaxMetersPerSecond", DEFAULT.maxMetersPerSecond),
        PathFile.number(robot, "onTheFlyMaxMetersPerSecondSquared", DEFAULT.maxMetersPerSecondSquared));
  }

  /**
   * The robot's reach in any heading: the bumpers' half-diagonal, or the far corner of the footprint when a
   * mechanism is out ({@link Footprint#reachMeters}).
   */
  public double halfDiagonalMeters() {
    return footprint.reachMeters();
  }

  /** How far obstacles are grown: the reach plus margin. */
  public double growMeters() {
    return halfDiagonalMeters() + marginMeters;
  }

  /** {@link #growMeters} for the bumpers alone (the half-diagonal plus margin), whatever the footprint. */
  public double bumperGrowMeters() {
    return Math.hypot(bumperLengthMeters, bumperWidthMeters) / 2 + marginMeters;
  }

  public PlannerConfig withMargin(double margin) {
    return new PlannerConfig(bumperLengthMeters, bumperWidthMeters, margin, arcStepRadians, maxRefits,
        checkStepMeters, maxMetersPerSecond, maxMetersPerSecondSquared, footprint);
  }

  public PlannerConfig withLimits(double maxSpeed, double maxAccel) {
    return new PlannerConfig(bumperLengthMeters, bumperWidthMeters, marginMeters, arcStepRadians, maxRefits,
        checkStepMeters, maxSpeed, maxAccel, footprint);
  }

  /** The same settings planning with {@code outline} (one of {@link Footprint#fromRobotFile}'s). */
  public PlannerConfig withFootprint(Footprint outline) {
    return new PlannerConfig(bumperLengthMeters, bumperWidthMeters, marginMeters, arcStepRadians, maxRefits,
        checkStepMeters, maxMetersPerSecond, maxMetersPerSecondSquared, outline);
  }
}
