package frc.team5712.path.wpilib;

import frc.team5712.path.core.FieldFrame;
import frc.team5712.path.core.FieldSpeeds;
import frc.team5712.path.core.Footprint;
import frc.team5712.path.core.Path;
import frc.team5712.path.core.Pose;
import frc.team5712.path.follow.FollowerConfig;
import frc.team5712.path.plan.OnTheFly;
import java.util.Optional;
import java.util.Set;
import java.util.function.BooleanSupplier;
import java.util.function.DoubleSupplier;
import java.util.function.Supplier;
import org.wpilib.command3.Command;
import org.wpilib.command3.Coroutine;
import org.wpilib.command3.Mechanism;
import org.wpilib.math.geometry.Pose2d;
import org.wpilib.math.geometry.Rotation2d;
import org.wpilib.system.Timer;

/**
 * An on-the-fly path around the field's obstacles (see {@link Pathfinding}, which builds these).
 * Plans when it starts, follows, re-plans when knocked off or asked, and, for {@link Pathfinding#thenFollow},
 * hands over to the library path's own follow command. Telemetry goes out as for a followed path, under
 * Path/&lt;name&gt; (the plan, each loop's state, and the planning figures).
 */
public final class PathfindCommand implements Command {
  private final Pathfinding ctx;
  private final Mechanism drive;
  private final String name;
  private final Pathfinding.Goal goal;
  private final Path handOver;
  private final FollowPathCommand follow;
  private final PathTelemetry telemetry;
  private double replanAbove = OnTheFly.DEFAULT_REPLAN_METERS;
  private Supplier<Optional<Pose2d>> movingGoal;
  private double goalSmoothingSeconds;
  private BooleanSupplier finishGate;
  private FollowerConfig config;
  private DoubleSupplier clock = Timer::getTimestamp;
  private Supplier<FieldFrame> frameSource;
  private Supplier<String> footprint;
  private OnTheFly run;
  private boolean following;

  PathfindCommand(Pathfinding ctx, Mechanism drive, String name, Pathfinding.Goal goal, Path handOver,
      FollowPathCommand follow) {
    this.ctx = ctx;
    this.drive = drive;
    this.name = name;
    this.goal = goal;
    this.handOver = handOver;
    this.follow = follow;
    this.telemetry = new PathTelemetry(name);
  }

  /** Re-plan when further than this off the path (default 0.2 m; +∞ = only when asked). */
  public PathfindCommand replanAbove(double meters) {
    this.replanAbove = meters;
    return this;
  }

  /** Finishes on a moving goal (real field frame, e.g. from vision); empty keeps the last. */
  public PathfindCommand withMovingGoal(Supplier<Optional<Pose2d>> realGoal) {
    return withMovingGoal(realGoal, 0.0);
  }

  /**
   * {@link #withMovingGoal(Supplier)} for a goal that arrives raw from a camera: its estimates are averaged over
   * {@code smoothingSeconds} (0.5 s is a good start). Leave it out for a goal that is already filtered
   * ({@link TagGoal}).
   */
  public PathfindCommand withMovingGoal(Supplier<Optional<Pose2d>> realGoal, double smoothingSeconds) {
    this.movingGoal = realGoal;
    this.goalSmoothingSeconds = smoothingSeconds;
    return this;
  }

  /**
   * Finished only once the robot is this close to the goal and this well turned (and stopped): 2 cm and 1°
   * unless set. Loosen it for a spot that needn't be exact, or for a robot that can't hold 2 cm.
   */
  public PathfindCommand withTolerance(double meters, Rotation2d heading) {
    setTolerance(meters, heading);
    return this;
  }

  /** {@link #withTolerance} for a command already built (it returns nothing, so it can stand on its own line). */
  public void setTolerance(double meters, Rotation2d heading) {
    this.config = ctx.config.toBuilder().positionToleranceMeters(meters)
        .headingToleranceRadians(heading.getRadians()).build();
  }

  /**
   * Holds the finish until {@code ready} is true: the robot drives to the goal and holds it, but the command
   * doesn't finish before then. For a goal that starts as a guess, e.g. the field map's spot until the cameras
   * have locked on to the tag ({@code tagGoal::hasLock}). Add a timeout in case it never comes true.
   */
  public PathfindCommand finishWhen(BooleanSupplier ready) {
    this.finishGate = ready;
    return this;
  }

  /**
   * Plans with this footprint's outline (robot.json's, or {@code "bumpers"}, the default), read when it starts
   * and on every re-plan's start: e.g. {@code () -> intake.isOut() ? "intakeOut" : "bumpers"}.
   */
  public PathfindCommand withFootprint(Supplier<String> footprintName) {
    this.footprint = footprintName;
    return this;
  }

  /** Replaces the clock (default {@code Timer.getTimestamp()}). */
  public PathfindCommand withClock(DoubleSupplier seconds) {
    this.clock = seconds;
    if (follow != null) {
      follow.setClock(seconds);
    }
    return this;
  }

  /** Replaces the alliance lookup (default: the driver station, read when it starts). */
  public PathfindCommand withFrame(Supplier<FieldFrame> frame) {
    this.frameSource = frame;
    if (follow != null) {
      follow.setFrame(frame);
    }
    return this;
  }

  /** Plans again on the next loop, from wherever the robot is. */
  public void replan() {
    if (run != null) {
      run.requestReplan();
    }
  }

  /** The current run (null before the first start). */
  public OnTheFly onTheFly() {
    return run;
  }

  @Override
  public String name() {
    return name;
  }

  @Override
  public Set<Mechanism> requirements() {
    return Set.of(drive);
  }

  @Override
  public void run(Coroutine coroutine) {
    FieldFrame frame = frameSource == null ? Conversions.allianceFrame(ctx.redFrame) : frameSource.get();
    following = false;
    String outline = footprint == null ? Footprint.BUMPERS : footprint.get();
    run = new OnTheFly(ctx.library.pathfinder(outline), config == null ? ctx.config : config, () -> goal.apply(frame))
        .preferring(ctx.library.widePathfinder(outline)).replanAbove(replanAbove)
        .onPlan(r -> {
          telemetry.plan(r.lastPlan(), r.replans());
          if (r.follower() != null) {
            telemetry.begin(r.follower());
          }
        });
    if (handOver != null) {
      run.arriving(handOver.spec().startMetersPerSecond(), Pathfinding.startTangent(handOver, frame));
    }
    if (movingGoal != null) {
      run.withMovingGoal(() -> movingGoal.get().map(Conversions::toPose), goalSmoothingSeconds);
    }
    if (finishGate != null) {
      run.finishWhen(finishGate);
    }
    if (run.start(clock.getAsDouble(), Conversions.toPose(ctx.pose.get()), measured())) {
      while (true) {
        Pose2d pose = ctx.pose.get();
        FieldSpeeds out = run.step(clock.getAsDouble(), Conversions.toPose(pose), measured());
        ctx.output.send(out, run.commandedAcceleration(), pose.getRotation());
        if (run.follower() != null) {
          telemetry.log(run.follower());
        }
        if (run.isFinished()) {
          break;
        }
        coroutine.yield();
      }
    }
    if (follow == null || run.failure() != null) {
      if (!run.rollingEnd()) {
        ctx.output.stop();
      }
      telemetry.end();
      return;
    }
    telemetry.end();
    following = true;
    OnTheFly handing = run;
    follow.setContinuingFrom(handing::endCommand);
    coroutine.yield(); // the path's command starts on the next loop, as the next command in a sequence would
    follow.run(coroutine);
  }

  private FieldSpeeds measured() {
    return Conversions.toFieldSpeeds(ctx.fieldVelocity.get());
  }

  @Override
  public void onCancel() {
    if (following) {
      follow.onCancel();
      return;
    }
    if (run != null) {
      run.cancel();
    }
    ctx.output.stop();
    telemetry.end();
  }

  /** The pose the robot is heading for now, in the real field frame (for tests and dashboards). */
  public Pose currentGoal(FieldFrame frame) {
    return goal.apply(frame);
  }
}
