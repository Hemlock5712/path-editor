package frc.team5712.path.wpilib;

import frc.team5712.path.core.FieldFrame;
import frc.team5712.path.core.Path;
import frc.team5712.path.core.PathSample;
import frc.team5712.path.core.Pose;
import frc.team5712.path.follow.FollowerConfig;
import frc.team5712.path.follow.PathFollower;
import java.util.function.Consumer;
import java.util.function.DoubleSupplier;
import java.util.function.Function;
import java.util.function.Supplier;
import org.wpilib.command3.Mechanism;
import org.wpilib.math.geometry.Pose2d;
import org.wpilib.math.geometry.Rotation2d;
import org.wpilib.math.geometry.Translation2d;
import org.wpilib.math.kinematics.ChassisVelocities;

/**
 * On-the-fly paths around the field's obstacles, for Commands v3. Build one in robot init, next to
 * the {@link PathLibrary} (which loaded field.json and built the visibility graph):
 *
 * <pre>
 * Pathfinding otf = new Pathfinding(paths, FollowerConfig.defaults(paths.robot()),
 *     drivetrain::getPose, drivetrain::getFieldVelocity, drivetrain::driveFieldVelocity,
 *     FieldFrame.RED_HALF_TURN);
 *
 * Command toSource = otf.to(drivetrain, new Pose2d(-7.6, 3.1, Rotation2d.k180deg));  // blue frame, flipped on red
 * Command toAmp = otf.toPoint(drivetrain, "Amp", Rotation2d.fromDegrees(90));     // an editor named point
 * Command toTag = otf.toTarget(drivetrain, vision::bestScoringPose);              // real field frame, as is
 * Command thenAuto = otf.thenFollow(drivetrain, "ToReef");                       // to the path's start, then the path
 * Command score = otf.follow(drivetrain, "ToScore").withMovingGoal(vision::scoringPoseIfSeen); // a library path, its end on vision
 * </pre>
 *
 * Each command plans when it starts, from the robot's measured pose and velocity (a few milliseconds:
 * the only path work at go), snapping a start or goal out of any grown obstacle, follows the plan with a
 * {@link PathFollower}, and plans again if the robot is knocked more than 20 cm off it
 * ({@link PathfindCommand#replanAbove}) or when asked ({@link PathfindCommand#replan}). The alliance is
 * read when the command starts: authored goals (poses, named points, a path's start) are blue-frame and
 * flipped with {@code redFrame} on red; {@link #toTarget} goals are used as given.
 */
public final class Pathfinding {
  final PathLibrary library;
  final FollowerConfig config;
  final Supplier<Pose2d> pose;
  final Supplier<ChassisVelocities> fieldVelocity;
  final Consumer<ChassisVelocities> fieldOutput;
  final DriveOutput output;
  Translation2d[] moduleLocations;
  WheelForceDrive forceDrive;
  final FieldFrame redFrame;
  DoubleSupplier clock;
  Supplier<FieldFrame> frame;
  Supplier<String> footprint;

  public Pathfinding(PathLibrary library, FollowerConfig config, Supplier<Pose2d> pose,
      Supplier<ChassisVelocities> fieldVelocity, Consumer<ChassisVelocities> fieldOutput, FieldFrame redFrame) {
    this.library = library;
    this.config = config;
    this.pose = pose;
    this.fieldVelocity = fieldVelocity;
    this.fieldOutput = fieldOutput;
    this.output = new DriveOutput(fieldOutput);
    this.redFrame = redFrame;
  }

  /** Every command built from here on reads this clock (default {@code Timer.getTimestamp()}), e.g. in tests. */
  public Pathfinding withClock(DoubleSupplier seconds) {
    this.clock = seconds;
    return this;
  }

  /** Every command built from here on reads the alliance from this (default: the driver station, at start). */
  public Pathfinding withFrame(Supplier<FieldFrame> frameSource) {
    this.frame = frameSource;
    return this;
  }

  /**
   * Every command built from here on sends the feed-forward too: {@code drive} gets each loop's velocity and the
   * push every wheel needs for the acceleration the follower asked for, in place of the velocity-only output.
   * See {@link WheelForceDrive} for the drivetrain's side.
   *
   * <pre>
   * otf.withWheelForces(drivetrain.getModuleLocations(), drivetrain::driveFieldVelocity);
   * </pre>
   *
   * @param moduleLocations the modules' positions, in the drivetrain's order
   */
  public Pathfinding withWheelForces(Translation2d[] moduleLocations, WheelForceDrive drive) {
    this.moduleLocations = moduleLocations.clone();
    this.forceDrive = drive;
    output.withWheelForces(library.robot(), moduleLocations, drive);
    return this;
  }

  private FollowPathCommand configured(FollowPathCommand c) {
    if (clock != null) {
      c.setClock(clock);
    }
    if (frame != null) {
      c.setFrame(frame);
    }
    if (forceDrive != null) {
      c.setWheelForces(library.robot(), moduleLocations, forceDrive);
    }
    return c;
  }

  /**
   * Every command built from here on plans with this footprint (robot.json's, or {@code "bumpers"}, the
   * default), read as each one starts: e.g. {@code () -> intake.isOut() ? "intakeOut" : "bumpers"}.
   */
  public Pathfinding withFootprint(Supplier<String> footprintName) {
    this.footprint = footprintName;
    return this;
  }

  private PathfindCommand configured(PathfindCommand c) {
    PathfindCommand out = c;
    if (clock != null) {
      out = out.withClock(clock);
    }
    if (frame != null) {
      out = out.withFrame(frame);
    }
    if (footprint != null) {
      out = out.withFootprint(footprint);
    }
    return out;
  }

  /** Where to go, in the real field frame, given the frame the robot runs in. */
  interface Goal extends Function<FieldFrame, Pose> {}

  static Goal blue(Pose2d goal) {
    Pose p = Conversions.toPose(goal);
    return frame -> frame.fromBlue(p);
  }

  Goal point(String name, Rotation2d heading) {
    double[] xy = library.namedPoint(name);
    Pose p = new Pose(xy[0], xy[1], heading.getRadians());
    return frame -> frame.fromBlue(p);
  }

  static Goal real(Supplier<Pose2d> goal) {
    return frame -> Conversions.toPose(goal.get());
  }

  /** The start of a library path, in the frame it will run in, and the direction it sets off in. */
  static Pose start(Path path, FieldFrame frame) {
    PathSample p = path.sample(0.0);
    return frame.fromBlue(new Pose(p.xMeters(), p.yMeters(), p.headingRadians()));
  }

  static double startTangent(Path path, FieldFrame frame) {
    PathSample p = path.sample(0.0);
    return frame.fromBlue(new Pose(p.xMeters(), p.yMeters(), Math.atan2(p.tangentY(), p.tangentX()))).headingRadians();
  }

  // ------------------------------------------------------------------------------ the commands

  /** To an authored pose (blue frame; flipped on red). */
  public PathfindCommand to(Mechanism drive, Pose2d blueGoal) {
    return configured(new PathfindCommand(this, drive, "Pathfind", blue(blueGoal), null, null));
  }

  /** To an editor named point (blue frame; flipped on red), arriving at {@code heading} (blue frame). */
  public PathfindCommand toPoint(Mechanism drive, String pointName, Rotation2d heading) {
    return configured(new PathfindCommand(this, drive, "Pathfind " + pointName, point(pointName, heading), null, null));
  }

  /** {@link #toPoint(Mechanism, String, Rotation2d)} by the point's generated name ({@code Points.X}). */
  public PathfindCommand toPoint(Mechanism drive, PointId point, Rotation2d heading) {
    return toPoint(drive, point.pointName(), heading);
  }

  /** To a pose read when it starts and at each re-plan, in the real field frame (not flipped). */
  public PathfindCommand toTarget(Mechanism drive, Supplier<Pose2d> realGoal) {
    return configured(new PathfindCommand(this, drive, "Pathfind", real(realGoal), null, null));
  }

  /**
   * To the start of the library path {@code pathName}, arriving along its start direction at its start speed
   * (a rolling hand-over when the path starts moving), then the path itself. The path's follower is built
   * here, in robot init; its events fire through {@code library.bindEvent}.
   */
  public PathfindCommand thenFollow(Mechanism drive, PathId path) {
    return thenFollow(drive, path.fileName());
  }

  /**
   * A library path on its own (no pathfinding first), its events bound through {@code library.bindEvent}:
   * {@code otf.follow(drive, Paths.TO_REEF)}. The follower is built here, in robot init.
   */
  public FollowPathCommand follow(Mechanism drive, PathId path) {
    return follow(drive, path.fileName());
  }

  public PathfindCommand thenFollow(Mechanism drive, String pathName) {
    Path path = library.get(pathName);
    FollowPathCommand follow = new FollowPathCommand(pathName, drive, new PathFollower(path, config), pose,
        fieldVelocity, fieldOutput, redFrame).withEvents(library);
    if (forceDrive != null) {
      follow.setWheelForces(library.robot(), moduleLocations, forceDrive);
    }
    return configured(new PathfindCommand(this, drive, "Pathfind to " + pathName, f -> start(path, f), path, follow));
  }

  /**
   * The library path {@code pathName} on its own, no pathfinding: a {@link FollowPathCommand} with this object's
   * drivetrain, follower settings, clock and alliance, its events bound through {@code library.bindEvent}. Add
   * {@link FollowPathCommand#withMovingGoal} to let its end follow a goal seen on the field.
   */
  public FollowPathCommand follow(Mechanism drive, String pathName) {
    return configured(new FollowPathCommand(pathName, drive, new PathFollower(library.get(pathName), config), pose,
        fieldVelocity, fieldOutput, redFrame).withEvents(library));
  }
}
